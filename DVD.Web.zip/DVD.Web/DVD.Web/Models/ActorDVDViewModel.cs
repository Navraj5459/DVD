﻿using DVD.Web.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVD.Web.Models
{
    public class ActorDVDViewModel
    {
        public ActorModel ActorModel { get; set; }
        public MemberModel MemberModel { get; set; }
        public List<DVDTitleModel> DVDTitleModel { get; set; }
        public List<ActorDVDCopy> ActorDVDCopy { get; set; }
        public List<DVDCopyModel> DVDCopyModel { get; set; }
        public List<MemberDVDLoan> MemberDVDLoan { get; set; }
        public List<NotReturnedDVD> NotReturnedDVD { get; set; }
    }
    public class ActorDVDCopy
    {
        public long DVDNumber { get; set; }
        public long DVDCopyNumber { get; set; }
    }
    public class MemberDVDLoan
    {
        public MemberModel MemberModel { get; set; }
        public string LoanedDVDCount { get; set; }
    }
    public class NotReturnedDVD
    {
        public string DVDNumber { get; set; }
        public string CopyNumber { get; set; }
        public string MemberFirstName { get; set; }
        public string MemberLastName { get; set; }
        public DateTime DateOut { get; set; }
        public string LoanedDVDCount { get; set; }
    }
    public class NotLoanedMemberList
    {
        public string MemberFirstName { get; set; }
        public string MemberLastName { get; set; }
        public string MemberAddress { get; set; }
        public DateTime DateOut { get; set; }
        public string DVDNumber { get; set; }
        public string NumberOfDays { get; set; }
    }
    public class NoCopyDVDTitle
    {
        public string DVDNumber { get; set; }
    }
    public class DVDAllListModel
    {
        public ProducerModel Producer { get; set; }
        public StudioModel Studio { get; set; }
        public CastMemberModel CastMember { get; set; }
        public ActorModel Actor { get; set; }
    }
    public class DVDCopyMemberModel
    {
        public string CopyNumber { get; set; }
        public List<SelectListItem> CopyNumberList { get; set; }
        public List<DVDCopyMemberViewModel> DVDCopyMemberViewModel { get; set; }
    }
    public class DVDCopyMemberViewModel
    {
        public string CopyNumber { get; set; }
        public string MemberFirstName { get; set; }
        public string MemberLastName { get; set; }
        public DateTime DateOut { get; set; }
        public DateTime DateDue { get; set; }
        public DateTime? DateReturned { get; set; }
        public string DVDNumber { get; set; }
    }
}
