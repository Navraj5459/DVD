﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVD.Web.Models
{
    public class DVDTitleModel
    {
        public long DVDNumber { get; set; }
        public long ProducerNumber { get; set; }
        public long CategoryNumber { get; set; }
        public long StudioNumber { get; set; }
        public string DateReleased { get; set; }
        public Decimal StandardCharge { get; set; }
        public Decimal PenaltyCharge { get; set; }
        public string Producer { get; set; }
        public string DVDCategory { get; set; }
        public string Studio { get; set; }
        public List<SelectListItem> ProducerList { get; set; }
        public List<SelectListItem> CategoryList { get; set; }
        public List<SelectListItem> StudioList { get; set; }
    }
}
