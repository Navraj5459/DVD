﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVD.Web.Models
{
    public class CastMemberModel
    {
        public long DVDNumber { get; set; }
        public long ActorNumber { get; set; }
        public string Actor { get; set; }
        public List<SelectListItem> DVDTitleList { get; set; }
        public List<SelectListItem> ActorList { get; set; }
    }
}
