﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace DVD.Web.EntityModel
{
    public class CastMember
    {
        [Key]
        public long CastMemberNumber { get; set; }
        public long DVDNumber { get; set; }
        public long ActorNumber { get; set; }
    }
}
