﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVD.Web.Library
{
    public  class StaticData
    {
        static IHttpContextAccessor _accessor;
        public StaticData(IHttpContextAccessor accessor)
        {
            _accessor = accessor;
        }
        public string GetSession(string val)
        {
            return _accessor.HttpContext.Session.GetString(val);
        }
    }
}
