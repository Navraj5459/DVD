﻿using DVD.Web.DbConnection;
using DVD.Web.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace DVD.Web.Controllers
{
    public class CommonController : Controller
    {
        DVDContext _db;
        public CommonController(DVDContext db)
        {
            _db = db;
        }
        #region 1
        public void ActorDVDTitleDDl(ActorDVDViewModel viewmodel)
        {
            var list = new List<SelectListItem>();
            var actorlist = _db.Actor.ToList();
            var items = new SelectListItem();
            items.Text = "Select Actor Last Name";
            items.Value = "";
            list.Add(items);
            foreach (var item in actorlist)
            {
                items = new SelectListItem();
                items.Text = item.ActorSurname;
                items.Value = item.ActorNumber.ToString();
                list.Add(items);
            }
            var model = new ActorModel();
            model.ActorLastNameList = list;
            viewmodel.ActorModel = model;
        }
        public IActionResult DVDByActor()
        {
            var viewmodel = new ActorDVDViewModel();
            ActorDVDTitleDDl(viewmodel);
            return View(viewmodel);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DVDByActor(ActorDVDViewModel viewmodel)
        {
            ModelState.Remove("ActorModel.ActorSurname");
            ModelState.Remove("ActorModel.ActorFirstName");
            var list = new List<DVDTitleModel>();
            if (ModelState.IsValid)
            {
                var castlist = _db.CastMember.Where(x => x.ActorNumber == viewmodel.ActorModel.ActorNumber).ToList();
                foreach (var item in castlist)
                {
                    var dvdtitlemodel = new DVDTitleModel();
                    var data = _db.DVDTitle.Where(x => x.DVDNumber == item.DVDNumber).FirstOrDefault();
                    dvdtitlemodel.DVDNumber = data.DVDNumber;
                    dvdtitlemodel.ProducerNumber = data.ProducerNumber;
                    dvdtitlemodel.CategoryNumber = data.CategoryNumber;
                    dvdtitlemodel.StudioNumber = data.StudioNumber;
                    dvdtitlemodel.StandardCharge = data.StandardCharge;
                    dvdtitlemodel.PenaltyCharge = data.PenaltyCharge;
                    list.Add(dvdtitlemodel);
                }
                viewmodel.DVDTitleModel = list;
            }
            else
            {
                viewmodel.DVDTitleModel = list;
            }
            ActorDVDTitleDDl(viewmodel);
            return View(viewmodel);
        }
        #endregion

        #region 2
        public void ActorCastCopyDDl(ActorDVDViewModel viewmodel)
        {
            var list = new List<SelectListItem>();
            var items = new SelectListItem();
            items.Text = "Select Actor Last Name";
            items.Value = "";
            list.Add(items);
            var actorlist = _db.Actor.FromSqlRaw("select A.* from Actor A inner join CastMember CM ON A.ActorNumber = CM.ActorNumber and(Select COUNT(*) from DVDCopy DC WHeRE DC.DVDNumber = CM.DVDNumber) >= 1").ToList();
            foreach (var item in actorlist)
            {
                items = new SelectListItem();
                items.Text = item.ActorSurname;
                items.Value = item.ActorNumber.ToString();
                list.Add(items);
            }
            var model = new ActorModel();
            model.ActorLastNameList = list;
            viewmodel.ActorModel = model;
        }
        public IActionResult DVDCopyByActor()
        {
            var viewmodel = new ActorDVDViewModel();
            ActorCastCopyDDl(viewmodel);
            return View(viewmodel);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DVDCopyByActor(ActorDVDViewModel viewmodel)
        {
            ModelState.Remove("ActorModel.ActorSurname");
            ModelState.Remove("ActorModel.ActorFirstName");
            var list = new List<ActorDVDCopy>();
            if (ModelState.IsValid)
            {
                var result = (from A in _db.Actor
                              join CM in _db.CastMember on A.ActorNumber equals CM.ActorNumber
                              where A.ActorNumber == viewmodel.ActorModel.ActorNumber
                              select new
                              {
                                  CM.DVDNumber,
                                  DVDCopyNumber = (from DC in _db.DVDCopy where CM.DVDNumber == DC.DVDNumber select DC).Count()
                              }).ToList();
                foreach (var item in result)
                {
                    var model = new ActorDVDCopy();
                    model.DVDNumber = item.DVDNumber;
                    model.DVDCopyNumber = item.DVDCopyNumber;
                    list.Add(model);
                }
                viewmodel.ActorDVDCopy = list;
            }
            else
            {
                viewmodel.ActorDVDCopy = list;
            }
            ActorCastCopyDDl(viewmodel);
            return View(viewmodel);
        }
        #endregion

        #region 3
        public void MemberListDDl(ActorDVDViewModel viewmodel)
        {
            var list = new List<SelectListItem>();
            var Memberlist = _db.Member.ToList();
            var items = new SelectListItem();
            items.Text = "Select Member Last Name";
            items.Value = "";
            list.Add(items);
            foreach (var item in Memberlist)
            {
                items = new SelectListItem();
                items.Text = item.MemberLastName;
                items.Value = item.MemberNumber.ToString();
                list.Add(items);
            }
            var model = new MemberModel();
            model.MemberList = list;
            viewmodel.MemberModel = model;
        }
        public IActionResult MemberLoanedDVD()
        {
            var viewmodel = new ActorDVDViewModel();
            MemberListDDl(viewmodel);
            return View(viewmodel);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult MemberLoanedDVD(ActorDVDViewModel viewmodel)
        {
            ModelState.Remove("MemberModel.MembershipCategoryNumber");
            ModelState.Remove("MemberModel.MemberLastName");
            ModelState.Remove("MemberModel.MemberFirstName");
            ModelState.Remove("MemberModel.MemberAddress");
            ModelState.Remove("MemberModel.MemberDOB");
            if (viewmodel.MemberModel.MemberNumber == null)
            {
                ModelState.AddModelError("MemberModel.MemberNumber", "Please Select Member");
            }
            var list = new List<DVDCopyModel>();
            if (ModelState.IsValid)
            {
                var result = _db.DVDCopy.FromSqlRaw("select DC.CopyNumber,DC.DVDNumber,DC.DatePurchased from Member M INNER JOIN Loan L ON M.MemberNumber = L.MemberNumber INNER JOIN DVDCopy DC ON DC.CopyNumber = L.CopyNumber WHERE M.MemberNumber = " + viewmodel.MemberModel.MemberNumber + " AND DATEDIFF(DAY, L.DATEOUT, GETDATE()) <= 31").ToList();
                foreach (var item in result)
                {
                    var model = new DVDCopyModel();
                    model.DVDNumber = item.DVDNumber;
                    model.CopyNumber = item.CopyNumber;
                    list.Add(model);
                }
                viewmodel.DVDCopyModel = list;
            }
            else
            {
                viewmodel.DVDCopyModel = list;
            }
            MemberListDDl(viewmodel);
            return View(viewmodel);
        }
        #endregion

        #region Member List With Loan DVD 8
        public IActionResult MemberDVDLoaned()
        {
            var list = new List<MemberDVDLoan>();
            if (ModelState.IsValid)
            {
                var result = (from M in _db.Member
                              select new
                              {
                                  M.MemberNumber,
                                  M.MembershipCategoryNumber,
                                  M.MemberLastName,
                                  M.MemberFirstName,
                                  M.MemberAddress,
                                  M.MemberDOB,
                                  LoanedDVDCount = (from L in _db.Loan where M.MemberNumber == L.MemberNumber where L.DateReturned == null select L).Count()
                              }).ToList();
                foreach (var item in result)
                {
                    var common = new MemberDVDLoan();
                    var model = new MemberModel();
                    model.MemberNumber = item.MemberNumber;
                    model.MembershipCategoryDescription = _db.MembershipCategory.Where(x => x.MembershipCategoryNumber == item.MembershipCategoryNumber).Select(x => x.MembershipCategoryDescription).FirstOrDefault();
                    model.MemberLastName = item.MemberLastName;
                    model.MemberFirstName = item.MemberFirstName;
                    model.MemberAddress = item.MemberAddress;
                    model.MemberDOB = item.MemberDOB;
                    common.LoanedDVDCount = item.LoanedDVDCount.ToString();
                    common.MemberModel = model;
                    list.Add(common);
                }
            }
            return View(list);
        }
        #endregion

        #region Not Returned DVD By Member 11
        public IActionResult NotReturnedDVD()
        {
            var list = new List<NotReturnedDVD>();
            if (ModelState.IsValid)
            {
                var result = ((from L in _db.Loan
                              join M in _db.Member on L.MemberNumber equals M.MemberNumber
                              join DC in _db.DVDCopy on L.CopyNumber equals DC.CopyNumber
                              join DT in _db.DVDTitle on DC.DVDNumber equals DT.DVDNumber
                              where L.DateReturned == null
                              where System.DateTime.Compare(L.DateDue,System.DateTime.Today) < 0
                              select new
                              {
                                  DT.DVDNumber,
                                  DC.CopyNumber,
                                  M.MemberLastName,
                                  M.MemberFirstName,
                                  L.DateOut,
                                  LoanedDVDCount = (from LO in _db.Loan where LO.CopyNumber == L.CopyNumber where LO.MemberNumber == L.MemberNumber where LO.DateReturned == null where System.DateTime.Compare(LO.DateDue, System.DateTime.Today) < 0 select LO).Count()
                              }).ToList()).Distinct();
                if (result != null)
                {
                    foreach (var item in result)
                    {
                        var model = new NotReturnedDVD();
                        model.DVDNumber = item.DVDNumber.ToString();
                        model.MemberLastName = item.MemberLastName;
                        model.MemberFirstName = item.MemberFirstName;
                        model.CopyNumber = item.CopyNumber.ToString();
                        model.DateOut = item.DateOut;
                        model.LoanedDVDCount = item.LoanedDVDCount.ToString();
                        model.LoanedDVDCount = item.LoanedDVDCount.ToString();
                        list.Add(model);
                    }
                }
            }
            return View(list);
        }
        #endregion

        #region 12
        public ActionResult NotLoanedMemberList()
        {
            var list = new List<NotLoanedMemberList>();
            var loanmemberresult = (from L in _db.Loan
                                    where System.DateTime.Compare(L.DateOut.AddDays(31), System.DateTime.Now.Date) > 0
                                    select new
                                    {
                                        L.MemberNumber
                                    }).ToList();
            var memberresult = (from M in _db.Member
                               select new
                               {
                                   M.MemberNumber
                               }).ToList();
            var actualmemberlist = memberresult.Except(loanmemberresult).ToList();
            var result = (from M in _db.Member
                          join L in _db.Loan on M.MemberNumber equals L.MemberNumber
                          join DC in _db.DVDCopy on L.CopyNumber equals DC.CopyNumber
                          join DT in _db.DVDTitle on DC.DVDNumber equals DT.DVDNumber
                          where System.DateTime.Compare(L.DateOut.AddDays(31), System.DateTime.Now.Date) < 0
                          select new
                          {
                              M.MemberNumber,
                              M.MemberFirstName,
                              M.MemberLastName,
                              M.MemberAddress,
                              L.DateOut,
                              DT.DVDNumber,
                              NumberOfDays = (System.DateTime.Today - L.DateOut).Days
                          }).ToList();
            if (result != null)
            {
                foreach (var item in result)
                {
                    foreach(var items in actualmemberlist)
                    {
                        if(item.MemberNumber == items.MemberNumber)
                        {
                            var model = new NotLoanedMemberList();
                            model.MemberFirstName = item.MemberFirstName;
                            model.MemberLastName = item.MemberLastName;
                            model.MemberAddress = item.MemberAddress;
                            model.DateOut = item.DateOut;
                            model.DVDNumber = item.DVDNumber.ToString();
                            model.NumberOfDays = item.NumberOfDays.ToString();
                            list.Add(model);
                        }
                    }
                }
            }
            return View(list);
        }
        #endregion

        #region 13
        public ActionResult NoCopyDVDTitle()
        {
            var list = new List<NoCopyDVDTitle>();
            var loandvdcopyresult = (from L in _db.Loan
                                    where System.DateTime.Compare(L.DateOut.AddDays(31), System.DateTime.Now.Date) > 0
                                    select new
                                    {
                                        L.CopyNumber
                                    }).ToList();
            var dvdcopyresult = (from DC in _db.DVDCopy
                                select new
                                {
                                    DC.CopyNumber
                                }).ToList();
            var actualdvdcopylist = dvdcopyresult.Except(loandvdcopyresult).ToList();
            var result = (from DC in _db.DVDCopy
                          join DT in _db.DVDTitle on DC.DVDNumber equals DT.DVDNumber
                          select new
                          {
                              DT.DVDNumber,
                              DC.CopyNumber
                          }).ToList();
            if (result != null)
            {
                foreach (var item in result)
                {
                    foreach (var items in actualdvdcopylist)
                    {
                        if (item.CopyNumber == items.CopyNumber)
                        {
                            var model = new NoCopyDVDTitle();
                            model.DVDNumber = item.DVDNumber.ToString();
                            list.Add(model);
                        }
                    }
                }
            }
            return View(list);
        }
        #endregion

        #region 4
        public ActionResult DVDAllList()
        {
            var list = new List<DVDAllListModel>();
            var result = (from DT in _db.DVDTitle
                          join P in _db.Producer on DT.ProducerNumber equals P.ProducerNumber
                          join S in _db.Studio on DT.StudioNumber equals S.StudioNumber
                          join CM in _db.CastMember on DT.DVDNumber equals CM.DVDNumber
                          select new
                          {
                              P.ProducerNumber,
                              P.ProducerName,
                              S.StudioNumber,
                              S.StudioName,
                              CM.DVDNumber,
                              DT.DateReleased,
                              CM.ActorNumber
                          }).ToList().OrderBy(x=>x.DateReleased);
            var actorlist = (from A in _db.Actor
                                     select new
                                     {
                                         A.ActorNumber,
                                         A.ActorFirstName,
                                         A.ActorSurname
                                     }).ToList().OrderBy(x => x.ActorSurname);
            if (result != null)
            {
                foreach (var item in result)
                {
                    foreach (var items in actorlist)
                    {
                        if (item.ActorNumber == items.ActorNumber)
                        {
                            var model = new DVDAllListModel();
                            var actor = new ActorModel();
                            actor.ActorNumber = items.ActorNumber;
                            actor.ActorFirstName = items.ActorFirstName;
                            actor.ActorSurname = items.ActorSurname;
                            model.Actor = actor;
                            var producer = new ProducerModel();
                            producer.ProducerNumber = item.ProducerNumber;
                            producer.ProducerName = item.ProducerName;
                            model.Producer = producer;
                            var studio = new StudioModel();
                            studio.StudioNumber = item.StudioNumber;
                            studio.StudioName = item.StudioName;
                            model.Studio = studio;
                            var castmember = new CastMemberModel();
                            castmember.DVDNumber = item.DVDNumber;
                            model.CastMember = castmember;
                            list.Add(model);
                        }
                    }
                }
            }
            list.OrderBy(x => x.Actor.ActorSurname);
            return View(list);
        }
        #endregion

        #region 5
        public List<SelectListItem> DVDCopyList()
        {
            var list = new List<SelectListItem>();
            var selectitem = new SelectListItem();
            selectitem.Text = "Select Copy Number";
            selectitem.Value = "";
            list.Add(selectitem);
            var data = _db.DVDCopy.ToList();
            foreach (var item in data)
            {
                selectitem = new SelectListItem();
                selectitem.Text = item.CopyNumber.ToString();
                selectitem.Value = item.CopyNumber.ToString();
                list.Add(selectitem);
            }
            return list;
        }
        public ActionResult DVDCopyMemberDetail()
        {
            var model = new DVDCopyMemberModel();
            var list = DVDCopyList();
            model.CopyNumberList = list;
            return View(model);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DVDCopyMemberDetail(DVDCopyMemberModel model)
        {
            if (string.IsNullOrEmpty(model.CopyNumber))
            {
                ModelState.AddModelError("CopyNumber", "Please Select Copy Number!");
            }
            if (ModelState.IsValid)
            {
                var list = new List<DVDCopyMemberViewModel>();
                var result = ((from DC in _db.DVDCopy
                             join L in _db.Loan on DC.CopyNumber equals L.CopyNumber
                             join M in _db.Member on L.MemberNumber equals M.MemberNumber
                             join DT in _db.DVDTitle on DC.DVDNumber equals DT.DVDNumber
                             where DC.CopyNumber == Convert.ToInt64(model.CopyNumber)
                             select new
                             {
                                 M.MemberFirstName,
                                 M.MemberLastName,
                                 L.DateOut,
                                 L.DateDue,
                                 L.DateReturned,
                                 DT.DVDNumber
                             }).ToList()).OrderByDescending(x=>x.DateOut);
                foreach(var item in result)
                {
                    var data = new DVDCopyMemberViewModel();
                    data.MemberFirstName = item.MemberFirstName;
                    data.MemberLastName = item.MemberLastName;
                    data.DateOut = item.DateOut;
                    data.DateDue = item.DateDue;
                    data.DateReturned = item.DateReturned;
                    data.DVDNumber = item.DVDNumber.ToString();
                    list.Add(data);
                }
                model.DVDCopyMemberViewModel = list;
            }
            model.CopyNumberList = DVDCopyList();
            return View(model);
        }

        #endregion
    }
}
