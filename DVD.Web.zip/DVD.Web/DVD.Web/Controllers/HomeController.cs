﻿using DVD.Web.DbConnection;
using DVD.Web.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace DVD.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private DVDContext _dvdcontext;
        public HomeController(ILogger<HomeController> logger, DVDContext dvdcontext)
        {
            _logger = logger;
            _dvdcontext = dvdcontext;
        }

        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                var data = _dvdcontext.User.Where(x => x.UserName == model.UserName).FirstOrDefault();
                if(data != null)
                {
                    var validuser = _dvdcontext.User.Where(x => x.UserName == model.UserName).Where(x => x.UserPassword == model.UserPassword).FirstOrDefault();
                    if(validuser != null)
                    {
                        HttpContext.Session.SetString("UserNumber", validuser.UserNumber.ToString());
                        HttpContext.Session.SetString("UserType", validuser.UserType);
                        HttpContext.Session.SetString("UserName", validuser.UserName);
                        return Redirect("/Home/Index");
                    }
                    else
                    {
                        ModelState.AddModelError("UserPassword", "USER PASSWORD DOES NOT MATCH!");
                        return View();
                    }
                }
                else
                {
                    ModelState.AddModelError("UserName", "USER NAME NOT FOUND!");
                    return View();
                }
            }
            return View();
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public ActionResult LogOut()
        {
            HttpContext.Session.SetString("UserNumber", "");
            HttpContext.Session.SetString("UserType", "");
            HttpContext.Session.SetString("UserName", "");
            return Redirect("/Home/Login");
        }
        public ActionResult PasswordChange()
        {
            var username = HttpContext.Session.GetString("UserName");
            if (!string.IsNullOrEmpty(username))
            {
                var model = new UserModel();
                model.UserName = username;
                return View(model);
            }
            else
            {
                return Redirect("/Home/LogOut");
            }
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PasswordChange(UserModel model)
        {
            var username = HttpContext.Session.GetString("UserName");
            if (!string.IsNullOrEmpty(username))
            {
                ModelState.Remove("UserType");
                ModelState.Remove("UserName");
                if (ModelState.IsValid)
                {
                    var entitymodel = _dvdcontext.User.Where(x => x.UserName == username).FirstOrDefault();
                    if(entitymodel != null)
                    {
                        entitymodel.UserPassword = model.UserPassword;
                        _dvdcontext.SaveChanges();
                        return Redirect("/Home/LogOut");
                    }
                    else
                    {
                        return View(model);
                    }
                }
                else
                {
                    return View(model);
                }
            }
            else
            {
                return Redirect("/Home/LogOut");
            }
        }
    }
}
