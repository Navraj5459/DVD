﻿using DVD.Web.DbConnection;
using DVD.Web.EntityModel;
using DVD.Web.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVD.Web.Controllers
{
    public class CastMemberController : Controller
    {
        DVDContext _dbconnection;
        public CastMemberController(DVDContext dbconnection)
        {
            _dbconnection = dbconnection;
        }
        public void DDL(CastMemberModel model)
        {
            var Actoritems = _dbconnection.Actor.ToList();
            var Actorlist = new List<SelectListItem>();
            var Actormodel = new SelectListItem();
            Actormodel.Value = "";
            Actormodel.Text = "Select Actor Type";
            Actorlist.Add(Actormodel);
            foreach (var item in Actoritems)
            {
                var data = new SelectListItem();
                data.Value = item.ActorNumber.ToString();
                data.Text = string.Concat(item.ActorFirstName, " ", item.ActorSurname);
                if (model.ActorNumber == item.ActorNumber)
                {
                    data.Selected = true;
                }
                Actorlist.Add(data);
            }
            model.ActorList = Actorlist;

            var dvdtitleitems = _dbconnection.DVDTitle.ToList();
            var dvdtitlelist = new List<SelectListItem>();
            var dvdtitlemodel = new SelectListItem();
            dvdtitlemodel.Value = "";
            dvdtitlemodel.Text = "Select DVD Title";
            dvdtitlelist.Add(dvdtitlemodel);
            foreach (var item in dvdtitleitems)
            {
                var data = new SelectListItem();
                data.Value = item.DVDNumber.ToString();
                data.Text = item.DVDNumber.ToString();
                if (model.DVDNumber == item.DVDNumber)
                {
                    data.Selected = true;
                }
                dvdtitlelist.Add(data);
            }
            model.DVDTitleList = dvdtitlelist;
        }
        public ActionResult Index()
        {
            var list = _dbconnection.CastMember.ToList();
            var lst = new List<CastMemberModel>();
            foreach (var item in list)
            {
                var model = new CastMemberModel();
                model.DVDNumber = item.DVDNumber;
                model.ActorNumber = item.ActorNumber;
                model.Actor = string.Concat(_dbconnection.Actor.Where(x => x.ActorNumber == item.ActorNumber).Select(x => x.ActorFirstName).FirstOrDefault(), " ", _dbconnection.Actor.Where(x => x.ActorNumber == item.ActorNumber).Select(x => x.ActorSurname).FirstOrDefault());
                lst.Add(model);
            }
            return View(lst);
        }
        public ActionResult AddCastMember()
        {
            var model = new CastMemberModel();
            DDL(model);
            return View(model);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddCastMember(CastMemberModel model)
        {
            if (ModelState.IsValid)
            {
                var entitymodel = new CastMember();
                entitymodel.ActorNumber = model.ActorNumber;
                entitymodel.DVDNumber = model.DVDNumber;
                var data = _dbconnection.Add<CastMember>(entitymodel);
                _dbconnection.SaveChanges();
                return Redirect("/CastMember/Index");
            }
            else
            {
                var errors = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                ViewData["Error"] = errors;
                DDL(model);
                return View(model);
            }
        }
        //public ActionResult UpdateCastMember()
        //{
        //    if (Request.Query.ContainsKey("id"))
        //    {
        //        var id = Request.Query["id"].ToString();
        //        var data = _dbconnection.CastMember.Where(x => x.ActorNumber == Convert.ToInt32(id)).FirstOrDefault();
        //        if (data != null)
        //        {
        //            var model = new CastMemberModel();
        //            model.ActorNumber = data.ActorNumber;
        //            model.DVDNumber = data.DVDNumber;
        //            DDL(model);
        //            return View(model);
        //        }
        //        else
        //        {
        //            return Redirect("/CastMember/Index");
        //        }
        //    }
        //    else
        //    {
        //        return Redirect("/CastMember/Index");
        //    }
        //}
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult UpdateCastMember(CastMemberModel model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        var item = _dbconnection.CastMember.Where(x => x.ActorNumber == model.ActorNumber).FirstOrDefault();
        //        if (item != null)
        //        {
        //            item.ActorNumber = model.ActorNumber;
        //            item.DVDNumber = model.DVDNumber;
        //            _dbconnection.SaveChanges();
        //            return Redirect("/CastMember/Index");
        //        }
        //        else
        //        {
        //            ViewData["Error"] = "Cast Member not found!";
        //            return Redirect("/CastMember/UpdateCastMember?id=" + model.ActorNumber);
        //        }
        //    }
        //    else
        //    {
        //        var errors = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
        //        ViewData["Error"] = errors;
        //        return Redirect("/CastMember/UpdateCastMember?id=" + model.ActorNumber);
        //    }
        //}
        public ActionResult DeleteCastMember()
        {
            if (Request.Query.ContainsKey("dvdnumber") && Request.Query.ContainsKey("actornumber"))
            {
                var dvdnumber = Request.Query["dvdnumber"].ToString();
                var actornumber = Request.Query["actornumber"].ToString();
                var data = _dbconnection.CastMember.Where(x => x.ActorNumber == Convert.ToInt32(actornumber)).Where(x => x.DVDNumber == Convert.ToInt32(dvdnumber)).FirstOrDefault();
                if (data != null)
                {
                    _dbconnection.CastMember.Remove(data);
                    _dbconnection.SaveChanges();
                    ViewData["Error"] = "Cast Member deleted successfully!";
                    return Redirect("/CastMember/Index");
                }
                else
                {
                    ViewData["Error"] = "Cast Member Not found!";
                    return Redirect("/CastMember/Index");
                }
            }
            else
            {
                ViewData["Error"] = "Cast Member Not found!";
                return Redirect("/CastMember/Index");
            }
        }
    }
}
