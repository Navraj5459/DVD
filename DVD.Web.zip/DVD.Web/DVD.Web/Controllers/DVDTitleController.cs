﻿using DVD.Web.DbConnection;
using DVD.Web.EntityModel;
using DVD.Web.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace DVD.Web.Controllers
{
    public class DVDTitleController : Controller
    {
        DVDContext _dbconnection;
        public DVDTitleController(DVDContext dbconnection)
        {
            _dbconnection = dbconnection;
        }
        public void DDL(DVDTitleModel model)
        {
            var produceritems = _dbconnection.Producer.ToList();
            var producerlist = new List<SelectListItem>();
            var producermodel = new SelectListItem();
            producermodel.Value = "";
            producermodel.Text = "Select Producer";
            producerlist.Add(producermodel);
            foreach (var item in produceritems)
            {
                var data = new SelectListItem();
                data.Value = item.ProducerNumber.ToString();
                data.Text = item.ProducerName.ToString();
                if (model.ProducerNumber == item.ProducerNumber)
                {
                    data.Selected = true;
                }
                producerlist.Add(data);
            }
            model.ProducerList = producerlist;

            var dvdcategoryitems = _dbconnection.DVDCategory.ToList();
            var dvdcategorylist = new List<SelectListItem>();
            var dvdcategorymodel = new SelectListItem();
            dvdcategorymodel.Value = "";
            dvdcategorymodel.Text = "Select DVD Category";
            dvdcategorylist.Add(dvdcategorymodel);
            foreach (var item in dvdcategoryitems)
            {
                var data = new SelectListItem();
                data.Value = item.CategoryNumber.ToString();
                data.Text = item.CategoryDescription.ToString();
                if (model.CategoryNumber == item.CategoryNumber)
                {
                    data.Selected = true;
                }
                dvdcategorylist.Add(data);
            }
            model.CategoryList = dvdcategorylist;

            var studioitems = _dbconnection.Studio.ToList();
            var studiolist = new List<SelectListItem>();
            var studiomodel = new SelectListItem();
            studiomodel.Value = "";
            studiomodel.Text = "Select Studio";
            studiolist.Add(studiomodel);
            foreach (var item in studioitems)
            {
                var data = new SelectListItem();
                data.Value = item.StudioNumber.ToString();
                data.Text = item.StudioName.ToString();
                if (model.StudioNumber == item.StudioNumber)
                {
                    data.Selected = true;
                }
                studiolist.Add(data);
            }
            model.StudioList = studiolist;
        }
        public ActionResult Index()
        {
            var list = _dbconnection.DVDTitle.ToList();
            var lst = new List<DVDTitleModel>();
            foreach (var item in list)
            {
                var model = new DVDTitleModel();
                model.DVDNumber = item.DVDNumber;
                model.Producer = _dbconnection.Producer.Where(x => x.ProducerNumber == item.ProducerNumber).Select(x => x.ProducerName).FirstOrDefault();
                model.DVDCategory = _dbconnection.DVDCategory.Where(x => x.CategoryNumber == item.CategoryNumber).Select(x => x.CategoryDescription).FirstOrDefault();
                model.Studio = _dbconnection.Studio.Where(x => x.StudioNumber == item.StudioNumber).Select(x => x.StudioName).FirstOrDefault();
                model.DateReleased = item.DateReleased.ToString();
                model.StandardCharge = item.StandardCharge;
                model.PenaltyCharge = item.PenaltyCharge;
                lst.Add(model);
            }
            return View(lst);
        }
        public ActionResult AddDVDTitle()
        {
            var model = new DVDTitleModel();
            DDL(model);
            return View(model);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddDVDTitle(DVDTitleModel model)
        {
            if (ModelState.IsValid)
            {
                var entitymodel = new DVDTitle();
                entitymodel.ProducerNumber = model.ProducerNumber;
                entitymodel.CategoryNumber = model.CategoryNumber;
                entitymodel.StudioNumber = model.StudioNumber;
                entitymodel.DateReleased = Convert.ToDateTime(model.DateReleased);
                entitymodel.StandardCharge = model.StandardCharge;
                entitymodel.PenaltyCharge = model.PenaltyCharge;
                var data = _dbconnection.Add<DVDTitle>(entitymodel);
                _dbconnection.SaveChanges();
                return Redirect("/DVDTitle/Index");
            }
            else
            {
                var errors = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                ViewData["Error"] = errors;
                DDL(model);
                return View(model);
            }
        }
        public ActionResult UpdateDVDTitle()
        {
            if (Request.Query.ContainsKey("id"))
            {
                var id = Request.Query["id"].ToString();
                var data = _dbconnection.DVDTitle.Where(x => x.DVDNumber == Convert.ToInt32(id)).FirstOrDefault();
                if (data != null)
                {
                    var model = new DVDTitleModel();
                    model.DVDNumber = data.DVDNumber;
                    model.ProducerNumber = data.ProducerNumber;
                    model.CategoryNumber = data.CategoryNumber;
                    model.StudioNumber = data.StudioNumber;
                    model.StandardCharge = data.StandardCharge;
                    model.PenaltyCharge = data.PenaltyCharge;
                    model.DateReleased = string.IsNullOrEmpty(data.DateReleased.ToString()) ? null :  Convert.ToDateTime(data.DateReleased).ToString("MM/dd/yyyy").ToString();
                    DDL(model);
                    return View(model);
                }
                else
                {
                    return Redirect("/DVDTitle/Index");
                }
            }
            else
            {
                return Redirect("/DVDTitle/Index");
            }
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateDVDTitle(DVDTitleModel model)
        {
            if (ModelState.IsValid)
            {
                var item = _dbconnection.DVDTitle.Where(x => x.DVDNumber == model.DVDNumber).FirstOrDefault();
                if (item != null)
                {
                    item.ProducerNumber = model.ProducerNumber;
                    item.CategoryNumber = model.CategoryNumber;
                    item.StudioNumber = model.StudioNumber;
                    item.DateReleased = string.IsNullOrEmpty(model.DateReleased) ? null : Convert.ToDateTime(model.DateReleased);
                    item.StandardCharge = model.StandardCharge;
                    item.PenaltyCharge = model.PenaltyCharge;
                    _dbconnection.SaveChanges();
                    return Redirect("/DVDTitle/Index");
                }
                else
                {
                    ViewData["Error"] = "DVD Title not found!";
                    return Redirect("/DVDTitle/UpdateDVDTitle?id=" + model.DVDNumber);
                }
            }
            else
            {
                var errors = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                ViewData["Error"] = errors;
                return Redirect("/DVDTitle/UpdateDVDTitle?id=" + model.DVDNumber);
            }
        }
        public ActionResult DeleteDVDTitle()
        {
            if (Request.Query.ContainsKey("id"))
            {
                var id = Request.Query["id"].ToString();
                var data = _dbconnection.DVDTitle.Where(x => x.DVDNumber == Convert.ToInt32(id)).FirstOrDefault();
                if (data != null)
                {
                    _dbconnection.DVDTitle.Remove(data);
                    _dbconnection.SaveChanges();
                    ViewData["Error"] = "DVD Title deleted successfully!";
                    return Redirect("/DVDTitle/Index");
                }
                else
                {
                    ViewData["Error"] = "DVD Title Not found!";
                    return Redirect("/DVDTitle/Index");
                }
            }
            else
            {
                ViewData["Error"] = "DVD Title Not found!";
                return Redirect("/DVDTitle/Index");
            }
        }
    }
}
